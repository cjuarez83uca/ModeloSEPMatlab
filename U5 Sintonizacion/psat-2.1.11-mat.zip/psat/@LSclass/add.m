function a = add(a,data)

a.con = [a.con; data];
a = setup(a);

