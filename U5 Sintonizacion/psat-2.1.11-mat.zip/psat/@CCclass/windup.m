function windup(a)

fm_windup(a.q1,a.con(:,8),a.con(:,9),'td');
