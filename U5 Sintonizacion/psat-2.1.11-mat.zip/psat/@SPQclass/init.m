function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.id = [];
a.iq = [];
a.u = [];
