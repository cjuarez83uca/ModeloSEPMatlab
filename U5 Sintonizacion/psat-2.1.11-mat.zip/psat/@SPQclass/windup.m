function windup(a)

if ~a.n, return, end

