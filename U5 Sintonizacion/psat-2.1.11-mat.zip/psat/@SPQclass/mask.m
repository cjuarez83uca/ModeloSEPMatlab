function [x,y,s] = mask(a,idx,orient,vals)

return


