function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.Ik = [];
a.Vk = [];
a.pH2 = [];
a.pH2O = [];
a.pO2 = [];
a.qH2 = [];
a.m = [];
a.u = [];
