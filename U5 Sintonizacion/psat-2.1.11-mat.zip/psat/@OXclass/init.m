function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.syn = [];
a.exc = [];
a.v = [];
a.p = [];
a.q = [];
a.vref = [];
a.If = [];
a.u = [];
