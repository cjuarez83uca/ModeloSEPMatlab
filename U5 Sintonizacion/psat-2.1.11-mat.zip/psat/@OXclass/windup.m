function windup(a)

fm_windup(a.v,a.con(:,7),0,'td');
