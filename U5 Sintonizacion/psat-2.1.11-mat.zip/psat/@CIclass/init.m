function a = init(a)

a.n = 0;
a.syn = cell(0,0);
a.M = [];
a.Mtot = [];
a.gen = [];
a.dgen = [];
a.wgen = [];
a.delta = [];
a.omega = [];
