function display(p)

disp(struct(p))
